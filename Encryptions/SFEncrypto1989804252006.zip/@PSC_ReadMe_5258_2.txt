Title: SFEncryptor
Description: TO SHOW THE POWER OF JAVA SECURITY SPECIALLY ENCRYPTION METHODS ALL THE NECESSARY FILES ARE PROVIDED FOR TESTING FOR THE USERS WHO ARE FAMILIER
WITH JAVA.IF YOU HAVE A QUESTIONS ABOUT THIS PLEASE E-MAIL AT manojsenanayake@gmail.com
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=5258&lngWId=2

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
